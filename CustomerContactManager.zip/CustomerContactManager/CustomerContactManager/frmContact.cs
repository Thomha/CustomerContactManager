﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerContactManager
{
    public partial class frmContact : Form
    {
        public frmContact(Contact obj)
        {
            InitializeComponent();
            bSourceContact.DataSource = obj;
        }

        public Contact ContactInfo { get { return bSourceContact.Current as Contact; } }

        private void btnCloseContact_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSaveContact_Click(object sender, EventArgs e)
        {
            bSourceContact.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void frmContact_Load(object sender, EventArgs e)
        {
            txtbContactID.Text = "ContactID";
            txtbContact.Text = "Contact1";
            txtbContactName.Text = "Name";
            txtbContactEmail.Text = "Email";
            txtbContactNumber.Text = "Number";
            txtbCustomerContactID.Text = "CustomerID";
            using (DbEntities db = new DbEntities())
            {

            }
        }
    }
}
