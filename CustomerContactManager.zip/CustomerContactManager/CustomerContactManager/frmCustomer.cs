﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerContactManager
{
    public partial class frmCustomer : Form
    {
        public frmCustomer(Customer obj)
        {
            InitializeComponent();
            bSourceCustomer.DataSource = obj;
        }

        public Customer CustomerInfo { get { return bSourceCustomer.Current as Customer; } }

        private void btnCloseApp_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSaveCustomer_Click(object sender, EventArgs e)
        {
            bSourceCustomer.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void FrmCustomer_Load(object sender, EventArgs e)
        {
            txtbCustomerID.Text = "CustomerID";
            txtbCustomer.Text = "Customer1";
            txtbCustomerName.Text = "Name";
            txtbLatitude.Text = "Latitude";
            txtbLongitude.Text = "Longitude";
            using (DbEntities db = new DbEntities())
            {
                
            }
        }
    }
}
