﻿namespace CustomerContactManager
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlCustomerTopMenu = new System.Windows.Forms.Panel();
            this.btnCloseCustomer = new System.Windows.Forms.Button();
            this.lblCustomerForm = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblCustomerLatitude = new System.Windows.Forms.Label();
            this.lblLongitude = new System.Windows.Forms.Label();
            this.txtbCustomerID = new System.Windows.Forms.TextBox();
            this.bSourceCustomer = new System.Windows.Forms.BindingSource(this.components);
            this.txtbCustomer = new System.Windows.Forms.TextBox();
            this.txtbCustomerName = new System.Windows.Forms.TextBox();
            this.txtbLatitude = new System.Windows.Forms.TextBox();
            this.txtbLongitude = new System.Windows.Forms.TextBox();
            this.btnSaveCustomer = new System.Windows.Forms.Button();
            this.pnlCustomerTopMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bSourceCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlCustomerTopMenu
            // 
            this.pnlCustomerTopMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(61)))), ((int)(((byte)(75)))));
            this.pnlCustomerTopMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCustomerTopMenu.Controls.Add(this.btnCloseCustomer);
            this.pnlCustomerTopMenu.Controls.Add(this.lblCustomerForm);
            this.pnlCustomerTopMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCustomerTopMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlCustomerTopMenu.Name = "pnlCustomerTopMenu";
            this.pnlCustomerTopMenu.Size = new System.Drawing.Size(422, 57);
            this.pnlCustomerTopMenu.TabIndex = 0;
            // 
            // btnCloseCustomer
            // 
            this.btnCloseCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(62)))), ((int)(((byte)(25)))));
            this.btnCloseCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCloseCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseCustomer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCloseCustomer.Location = new System.Drawing.Point(390, 0);
            this.btnCloseCustomer.Name = "btnCloseCustomer";
            this.btnCloseCustomer.Size = new System.Drawing.Size(30, 24);
            this.btnCloseCustomer.TabIndex = 2;
            this.btnCloseCustomer.Text = "X";
            this.btnCloseCustomer.UseVisualStyleBackColor = false;
            this.btnCloseCustomer.Click += new System.EventHandler(this.btnCloseApp_Click);
            // 
            // lblCustomerForm
            // 
            this.lblCustomerForm.AutoSize = true;
            this.lblCustomerForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomerForm.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerForm.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomerForm.Location = new System.Drawing.Point(0, 0);
            this.lblCustomerForm.Name = "lblCustomerForm";
            this.lblCustomerForm.Size = new System.Drawing.Size(140, 25);
            this.lblCustomerForm.TabIndex = 1;
            this.lblCustomerForm.Text = "Customer Info";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomerID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerID.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomerID.Location = new System.Drawing.Point(0, 57);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(123, 25);
            this.lblCustomerID.TabIndex = 2;
            this.lblCustomerID.Text = "Customer ID";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomer.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomer.Location = new System.Drawing.Point(0, 82);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(98, 25);
            this.lblCustomer.TabIndex = 3;
            this.lblCustomer.Text = "Customer";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomerName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomerName.Location = new System.Drawing.Point(0, 107);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(64, 25);
            this.lblCustomerName.TabIndex = 4;
            this.lblCustomerName.Text = "Name";
            // 
            // lblCustomerLatitude
            // 
            this.lblCustomerLatitude.AutoSize = true;
            this.lblCustomerLatitude.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomerLatitude.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerLatitude.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomerLatitude.Location = new System.Drawing.Point(0, 132);
            this.lblCustomerLatitude.Name = "lblCustomerLatitude";
            this.lblCustomerLatitude.Size = new System.Drawing.Size(85, 25);
            this.lblCustomerLatitude.TabIndex = 5;
            this.lblCustomerLatitude.Text = "Latitude";
            // 
            // lblLongitude
            // 
            this.lblLongitude.AutoSize = true;
            this.lblLongitude.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblLongitude.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLongitude.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblLongitude.Location = new System.Drawing.Point(0, 157);
            this.lblLongitude.Name = "lblLongitude";
            this.lblLongitude.Size = new System.Drawing.Size(104, 25);
            this.lblLongitude.TabIndex = 6;
            this.lblLongitude.Text = "Longitude";
            // 
            // txtbCustomerID
            // 
            this.txtbCustomerID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bSourceCustomer, "CustomerID", true));
            this.txtbCustomerID.Location = new System.Drawing.Point(150, 62);
            this.txtbCustomerID.Name = "txtbCustomerID";
            this.txtbCustomerID.Size = new System.Drawing.Size(267, 20);
            this.txtbCustomerID.TabIndex = 7;
            // 
            // bSourceCustomer
            // 
            this.bSourceCustomer.DataSource = typeof(CustomerContactManager.Customer);
            // 
            // txtbCustomer
            // 
            this.txtbCustomer.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bSourceCustomer, "Customer1", true));
            this.txtbCustomer.Location = new System.Drawing.Point(150, 87);
            this.txtbCustomer.Name = "txtbCustomer";
            this.txtbCustomer.Size = new System.Drawing.Size(267, 20);
            this.txtbCustomer.TabIndex = 8;
            // 
            // txtbCustomerName
            // 
            this.txtbCustomerName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bSourceCustomer, "Name", true));
            this.txtbCustomerName.Location = new System.Drawing.Point(150, 112);
            this.txtbCustomerName.Name = "txtbCustomerName";
            this.txtbCustomerName.Size = new System.Drawing.Size(267, 20);
            this.txtbCustomerName.TabIndex = 9;
            // 
            // txtbLatitude
            // 
            this.txtbLatitude.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bSourceCustomer, "Latitude", true));
            this.txtbLatitude.Location = new System.Drawing.Point(150, 138);
            this.txtbLatitude.Name = "txtbLatitude";
            this.txtbLatitude.Size = new System.Drawing.Size(267, 20);
            this.txtbLatitude.TabIndex = 10;
            // 
            // txtbLongitude
            // 
            this.txtbLongitude.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bSourceCustomer, "Longitude", true));
            this.txtbLongitude.Location = new System.Drawing.Point(150, 162);
            this.txtbLongitude.Name = "txtbLongitude";
            this.txtbLongitude.Size = new System.Drawing.Size(267, 20);
            this.txtbLongitude.TabIndex = 11;
            // 
            // btnSaveCustomer
            // 
            this.btnSaveCustomer.Location = new System.Drawing.Point(342, 188);
            this.btnSaveCustomer.Name = "btnSaveCustomer";
            this.btnSaveCustomer.Size = new System.Drawing.Size(75, 23);
            this.btnSaveCustomer.TabIndex = 12;
            this.btnSaveCustomer.Text = "Save";
            this.btnSaveCustomer.UseVisualStyleBackColor = true;
            this.btnSaveCustomer.Click += new System.EventHandler(this.btnSaveCustomer_Click);
            // 
            // frmCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(422, 221);
            this.Controls.Add(this.btnSaveCustomer);
            this.Controls.Add(this.txtbLongitude);
            this.Controls.Add(this.txtbLatitude);
            this.Controls.Add(this.txtbCustomerName);
            this.Controls.Add(this.txtbCustomer);
            this.Controls.Add(this.txtbCustomerID);
            this.Controls.Add(this.lblLongitude);
            this.Controls.Add(this.lblCustomerLatitude);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.pnlCustomerTopMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmCustomer";
            this.Load += new System.EventHandler(this.FrmCustomer_Load);
            this.pnlCustomerTopMenu.ResumeLayout(false);
            this.pnlCustomerTopMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bSourceCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCustomerTopMenu;
        private System.Windows.Forms.Label lblCustomerForm;
        private System.Windows.Forms.Button btnCloseCustomer;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblCustomerLatitude;
        private System.Windows.Forms.Label lblLongitude;
        private System.Windows.Forms.TextBox txtbCustomerID;
        private System.Windows.Forms.TextBox txtbCustomer;
        private System.Windows.Forms.TextBox txtbCustomerName;
        private System.Windows.Forms.TextBox txtbLatitude;
        private System.Windows.Forms.TextBox txtbLongitude;
        private System.Windows.Forms.Button btnSaveCustomer;
        private System.Windows.Forms.BindingSource bSourceCustomer;
    }
}