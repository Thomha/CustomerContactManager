﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerContactManager
{
    public partial class frmCCM : Form
    {
        public frmCCM()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (frmCustomer frm = new frmCustomer())
            {
                frm.ShowDialog();
            }
        }

        private void btnCloseApp_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnContactAdd_Click(object sender, EventArgs e)
        {
            using (frmContact frmC = new frmContact(new ))
            {
                frmC.ShowDialog();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            contactBindingSource.DataSource = db.Contacts.ToList();
            customerBindingSource.DataSource = db.Customers.ToList();
            Cursor.Current = Cursors.Default;
        }

        DbEntities db;

        private void frmCCM_Load(object sender, EventArgs e)
        {
            db = new DbEntities();
            contactBindingSource.DataSource = db.Contacts.ToList();
            customerBindingSource.DataSource = db.Customers.ToList();
        }
    }
}
