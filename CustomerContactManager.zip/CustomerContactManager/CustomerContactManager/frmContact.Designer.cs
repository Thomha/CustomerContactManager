﻿namespace CustomerContactManager
{
    partial class frmContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSaveContact = new System.Windows.Forms.Button();
            this.txtbContactNumber = new System.Windows.Forms.TextBox();
            this.txtbContactEmail = new System.Windows.Forms.TextBox();
            this.txtbContactName = new System.Windows.Forms.TextBox();
            this.txtbContact = new System.Windows.Forms.TextBox();
            this.txtbContactID = new System.Windows.Forms.TextBox();
            this.lblContactNumer = new System.Windows.Forms.Label();
            this.lblContactEmail = new System.Windows.Forms.Label();
            this.lblContactName = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblContactID = new System.Windows.Forms.Label();
            this.pnlCustomerTopMenu = new System.Windows.Forms.Panel();
            this.btnCloseContact = new System.Windows.Forms.Button();
            this.lblContactForm = new System.Windows.Forms.Label();
            this.txtbCustomerContactID = new System.Windows.Forms.TextBox();
            this.lblCustomerContactID = new System.Windows.Forms.Label();
            this.bSourceContact = new System.Windows.Forms.BindingSource(this.components);
            this.pnlCustomerTopMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bSourceContact)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSaveContact
            // 
            this.btnSaveContact.Location = new System.Drawing.Point(353, 213);
            this.btnSaveContact.Name = "btnSaveContact";
            this.btnSaveContact.Size = new System.Drawing.Size(75, 23);
            this.btnSaveContact.TabIndex = 24;
            this.btnSaveContact.Text = "Save";
            this.btnSaveContact.UseVisualStyleBackColor = true;
            this.btnSaveContact.Click += new System.EventHandler(this.btnSaveContact_Click);
            // 
            // txtbContactNumber
            // 
            this.txtbContactNumber.Location = new System.Drawing.Point(161, 162);
            this.txtbContactNumber.Name = "txtbContactNumber";
            this.txtbContactNumber.Size = new System.Drawing.Size(267, 20);
            this.txtbContactNumber.TabIndex = 23;
            // 
            // txtbContactEmail
            // 
            this.txtbContactEmail.Location = new System.Drawing.Point(161, 138);
            this.txtbContactEmail.Name = "txtbContactEmail";
            this.txtbContactEmail.Size = new System.Drawing.Size(267, 20);
            this.txtbContactEmail.TabIndex = 22;
            // 
            // txtbContactName
            // 
            this.txtbContactName.Location = new System.Drawing.Point(161, 112);
            this.txtbContactName.Name = "txtbContactName";
            this.txtbContactName.Size = new System.Drawing.Size(267, 20);
            this.txtbContactName.TabIndex = 21;
            // 
            // txtbContact
            // 
            this.txtbContact.Location = new System.Drawing.Point(161, 87);
            this.txtbContact.Name = "txtbContact";
            this.txtbContact.Size = new System.Drawing.Size(267, 20);
            this.txtbContact.TabIndex = 20;
            // 
            // txtbContactID
            // 
            this.txtbContactID.Location = new System.Drawing.Point(161, 62);
            this.txtbContactID.Name = "txtbContactID";
            this.txtbContactID.Size = new System.Drawing.Size(267, 20);
            this.txtbContactID.TabIndex = 19;
            // 
            // lblContactNumer
            // 
            this.lblContactNumer.AutoSize = true;
            this.lblContactNumer.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContactNumer.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactNumer.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContactNumer.Location = new System.Drawing.Point(0, 157);
            this.lblContactNumer.Name = "lblContactNumer";
            this.lblContactNumer.Size = new System.Drawing.Size(160, 25);
            this.lblContactNumer.TabIndex = 18;
            this.lblContactNumer.Text = "Contact Number";
            // 
            // lblContactEmail
            // 
            this.lblContactEmail.AutoSize = true;
            this.lblContactEmail.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContactEmail.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactEmail.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContactEmail.Location = new System.Drawing.Point(0, 132);
            this.lblContactEmail.Name = "lblContactEmail";
            this.lblContactEmail.Size = new System.Drawing.Size(59, 25);
            this.lblContactEmail.TabIndex = 17;
            this.lblContactEmail.Text = "Email";
            // 
            // lblContactName
            // 
            this.lblContactName.AutoSize = true;
            this.lblContactName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContactName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContactName.Location = new System.Drawing.Point(0, 107);
            this.lblContactName.Name = "lblContactName";
            this.lblContactName.Size = new System.Drawing.Size(64, 25);
            this.lblContactName.TabIndex = 16;
            this.lblContactName.Text = "Name";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContact.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContact.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContact.Location = new System.Drawing.Point(0, 82);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(81, 25);
            this.lblContact.TabIndex = 15;
            this.lblContact.Text = "Contact";
            // 
            // lblContactID
            // 
            this.lblContactID.AutoSize = true;
            this.lblContactID.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContactID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactID.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContactID.Location = new System.Drawing.Point(0, 57);
            this.lblContactID.Name = "lblContactID";
            this.lblContactID.Size = new System.Drawing.Size(106, 25);
            this.lblContactID.TabIndex = 14;
            this.lblContactID.Text = "Contact ID";
            // 
            // pnlCustomerTopMenu
            // 
            this.pnlCustomerTopMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(61)))), ((int)(((byte)(75)))));
            this.pnlCustomerTopMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCustomerTopMenu.Controls.Add(this.btnCloseContact);
            this.pnlCustomerTopMenu.Controls.Add(this.lblContactForm);
            this.pnlCustomerTopMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCustomerTopMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlCustomerTopMenu.Name = "pnlCustomerTopMenu";
            this.pnlCustomerTopMenu.Size = new System.Drawing.Size(434, 57);
            this.pnlCustomerTopMenu.TabIndex = 13;
            // 
            // btnCloseContact
            // 
            this.btnCloseContact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseContact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(62)))), ((int)(((byte)(25)))));
            this.btnCloseContact.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCloseContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseContact.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCloseContact.Location = new System.Drawing.Point(402, 0);
            this.btnCloseContact.Name = "btnCloseContact";
            this.btnCloseContact.Size = new System.Drawing.Size(30, 24);
            this.btnCloseContact.TabIndex = 2;
            this.btnCloseContact.Text = "X";
            this.btnCloseContact.UseVisualStyleBackColor = false;
            this.btnCloseContact.Click += new System.EventHandler(this.btnCloseContact_Click);
            // 
            // lblContactForm
            // 
            this.lblContactForm.AutoSize = true;
            this.lblContactForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContactForm.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactForm.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContactForm.Location = new System.Drawing.Point(0, 0);
            this.lblContactForm.Name = "lblContactForm";
            this.lblContactForm.Size = new System.Drawing.Size(123, 25);
            this.lblContactForm.TabIndex = 1;
            this.lblContactForm.Text = "Contact Info";
            // 
            // txtbCustomerContactID
            // 
            this.txtbCustomerContactID.Location = new System.Drawing.Point(161, 187);
            this.txtbCustomerContactID.Name = "txtbCustomerContactID";
            this.txtbCustomerContactID.Size = new System.Drawing.Size(267, 20);
            this.txtbCustomerContactID.TabIndex = 26;
            // 
            // lblCustomerContactID
            // 
            this.lblCustomerContactID.AutoSize = true;
            this.lblCustomerContactID.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCustomerContactID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerContactID.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCustomerContactID.Location = new System.Drawing.Point(0, 182);
            this.lblCustomerContactID.Name = "lblCustomerContactID";
            this.lblCustomerContactID.Size = new System.Drawing.Size(123, 25);
            this.lblCustomerContactID.TabIndex = 25;
            this.lblCustomerContactID.Text = "Customer ID";
            // 
            // bSourceContact
            // 
            this.bSourceContact.DataSource = typeof(CustomerContactManager.Contact);
            // 
            // frmContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(434, 241);
            this.Controls.Add(this.txtbCustomerContactID);
            this.Controls.Add(this.lblCustomerContactID);
            this.Controls.Add(this.btnSaveContact);
            this.Controls.Add(this.txtbContactNumber);
            this.Controls.Add(this.txtbContactEmail);
            this.Controls.Add(this.txtbContactName);
            this.Controls.Add(this.txtbContact);
            this.Controls.Add(this.txtbContactID);
            this.Controls.Add(this.lblContactNumer);
            this.Controls.Add(this.lblContactEmail);
            this.Controls.Add(this.lblContactName);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblContactID);
            this.Controls.Add(this.pnlCustomerTopMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContact";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmContact";
            this.Load += new System.EventHandler(this.frmContact_Load);
            this.pnlCustomerTopMenu.ResumeLayout(false);
            this.pnlCustomerTopMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bSourceContact)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSaveContact;
        private System.Windows.Forms.TextBox txtbContactNumber;
        private System.Windows.Forms.TextBox txtbContactEmail;
        private System.Windows.Forms.TextBox txtbContactName;
        private System.Windows.Forms.TextBox txtbContact;
        private System.Windows.Forms.TextBox txtbContactID;
        private System.Windows.Forms.Label lblContactNumer;
        private System.Windows.Forms.Label lblContactEmail;
        private System.Windows.Forms.Label lblContactName;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label lblContactID;
        private System.Windows.Forms.Panel pnlCustomerTopMenu;
        private System.Windows.Forms.Button btnCloseContact;
        private System.Windows.Forms.Label lblContactForm;
        private System.Windows.Forms.TextBox txtbCustomerContactID;
        private System.Windows.Forms.Label lblCustomerContactID;
        private System.Windows.Forms.BindingSource bSourceContact;
    }
}