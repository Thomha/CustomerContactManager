﻿namespace CustomerContactManager
{
    partial class frmCCM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlTopMenu = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnCloseApp = new System.Windows.Forms.Button();
            this.lblAppHeading = new System.Windows.Forms.Label();
            this.dgvCustomerTBL = new System.Windows.Forms.DataGridView();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customer1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.latitudeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.longitudeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvContactTBL = new System.Windows.Forms.DataGridView();
            this.contactIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contact1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblContacts = new System.Windows.Forms.Label();
            this.pnlContactsMenu = new System.Windows.Forms.Panel();
            this.btnContactSave = new System.Windows.Forms.Button();
            this.btnContactDelete = new System.Windows.Forms.Button();
            this.btnContactEdit = new System.Windows.Forms.Button();
            this.btnContactAdd = new System.Windows.Forms.Button();
            this.btnContactRefresh = new System.Windows.Forms.Button();
            this.pnlTopMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerTBL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContactTBL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactBindingSource)).BeginInit();
            this.pnlContactsMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopMenu
            // 
            this.pnlTopMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(61)))), ((int)(((byte)(75)))));
            this.pnlTopMenu.Controls.Add(this.btnSave);
            this.pnlTopMenu.Controls.Add(this.btnDelete);
            this.pnlTopMenu.Controls.Add(this.btnEdit);
            this.pnlTopMenu.Controls.Add(this.btnAdd);
            this.pnlTopMenu.Controls.Add(this.btnRefresh);
            this.pnlTopMenu.Controls.Add(this.btnCloseApp);
            this.pnlTopMenu.Controls.Add(this.lblAppHeading);
            this.pnlTopMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(61)))), ((int)(((byte)(75)))));
            this.pnlTopMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlTopMenu.Name = "pnlTopMenu";
            this.pnlTopMenu.Size = new System.Drawing.Size(974, 100);
            this.pnlTopMenu.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSave.Location = new System.Drawing.Point(300, 25);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 75);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDelete.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDelete.Location = new System.Drawing.Point(225, 25);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 75);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEdit.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnEdit.Location = new System.Drawing.Point(150, 25);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 75);
            this.btnEdit.TabIndex = 4;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Location = new System.Drawing.Point(75, 25);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 75);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRefresh.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRefresh.Location = new System.Drawing.Point(0, 25);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 75);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnCloseApp
            // 
            this.btnCloseApp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseApp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(62)))), ((int)(((byte)(25)))));
            this.btnCloseApp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCloseApp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseApp.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCloseApp.Location = new System.Drawing.Point(944, 3);
            this.btnCloseApp.Name = "btnCloseApp";
            this.btnCloseApp.Size = new System.Drawing.Size(30, 24);
            this.btnCloseApp.TabIndex = 1;
            this.btnCloseApp.Text = "X";
            this.btnCloseApp.UseVisualStyleBackColor = false;
            this.btnCloseApp.Click += new System.EventHandler(this.btnCloseApp_Click);
            // 
            // lblAppHeading
            // 
            this.lblAppHeading.AutoSize = true;
            this.lblAppHeading.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAppHeading.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppHeading.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblAppHeading.Location = new System.Drawing.Point(0, 0);
            this.lblAppHeading.Name = "lblAppHeading";
            this.lblAppHeading.Size = new System.Drawing.Size(257, 25);
            this.lblAppHeading.TabIndex = 0;
            this.lblAppHeading.Text = "Customer Contact Manager";
            // 
            // dgvCustomerTBL
            // 
            this.dgvCustomerTBL.AllowUserToOrderColumns = true;
            this.dgvCustomerTBL.AutoGenerateColumns = false;
            this.dgvCustomerTBL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerTBL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.customer1DataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.latitudeDataGridViewTextBoxColumn,
            this.longitudeDataGridViewTextBoxColumn,
            this.contactsDataGridViewTextBoxColumn});
            this.dgvCustomerTBL.DataSource = this.customerBindingSource;
            this.dgvCustomerTBL.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvCustomerTBL.Location = new System.Drawing.Point(0, 100);
            this.dgvCustomerTBL.Name = "dgvCustomerTBL";
            this.dgvCustomerTBL.Size = new System.Drawing.Size(974, 209);
            this.dgvCustomerTBL.TabIndex = 1;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer ID";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.Width = 155;
            // 
            // customer1DataGridViewTextBoxColumn
            // 
            this.customer1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customer1DataGridViewTextBoxColumn.DataPropertyName = "Customer1";
            this.customer1DataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customer1DataGridViewTextBoxColumn.Name = "customer1DataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // latitudeDataGridViewTextBoxColumn
            // 
            this.latitudeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.latitudeDataGridViewTextBoxColumn.DataPropertyName = "Latitude";
            this.latitudeDataGridViewTextBoxColumn.HeaderText = "Latitude";
            this.latitudeDataGridViewTextBoxColumn.Name = "latitudeDataGridViewTextBoxColumn";
            // 
            // longitudeDataGridViewTextBoxColumn
            // 
            this.longitudeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.longitudeDataGridViewTextBoxColumn.DataPropertyName = "Longitude";
            this.longitudeDataGridViewTextBoxColumn.HeaderText = "Longitude";
            this.longitudeDataGridViewTextBoxColumn.Name = "longitudeDataGridViewTextBoxColumn";
            // 
            // contactsDataGridViewTextBoxColumn
            // 
            this.contactsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contactsDataGridViewTextBoxColumn.DataPropertyName = "Contacts";
            this.contactsDataGridViewTextBoxColumn.HeaderText = "Contacts";
            this.contactsDataGridViewTextBoxColumn.Name = "contactsDataGridViewTextBoxColumn";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataSource = typeof(CustomerContactManager.Customer);
            // 
            // dgvContactTBL
            // 
            this.dgvContactTBL.AllowUserToOrderColumns = true;
            this.dgvContactTBL.AutoGenerateColumns = false;
            this.dgvContactTBL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContactTBL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.contactIDDataGridViewTextBoxColumn,
            this.contact1DataGridViewTextBoxColumn,
            this.contactNameDataGridViewTextBoxColumn,
            this.contactEmailDataGridViewTextBoxColumn,
            this.contactNumberDataGridViewTextBoxColumn,
            this.customerDataGridViewTextBoxColumn});
            this.dgvContactTBL.DataSource = this.contactBindingSource;
            this.dgvContactTBL.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvContactTBL.Location = new System.Drawing.Point(0, 359);
            this.dgvContactTBL.Name = "dgvContactTBL";
            this.dgvContactTBL.Size = new System.Drawing.Size(974, 247);
            this.dgvContactTBL.TabIndex = 2;
            // 
            // contactIDDataGridViewTextBoxColumn
            // 
            this.contactIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contactIDDataGridViewTextBoxColumn.DataPropertyName = "ContactID";
            this.contactIDDataGridViewTextBoxColumn.HeaderText = "Contact ID";
            this.contactIDDataGridViewTextBoxColumn.Name = "contactIDDataGridViewTextBoxColumn";
            // 
            // contact1DataGridViewTextBoxColumn
            // 
            this.contact1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contact1DataGridViewTextBoxColumn.DataPropertyName = "Contact1";
            this.contact1DataGridViewTextBoxColumn.HeaderText = "Contact";
            this.contact1DataGridViewTextBoxColumn.Name = "contact1DataGridViewTextBoxColumn";
            // 
            // contactNameDataGridViewTextBoxColumn
            // 
            this.contactNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contactNameDataGridViewTextBoxColumn.DataPropertyName = "ContactName";
            this.contactNameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.contactNameDataGridViewTextBoxColumn.Name = "contactNameDataGridViewTextBoxColumn";
            // 
            // contactEmailDataGridViewTextBoxColumn
            // 
            this.contactEmailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contactEmailDataGridViewTextBoxColumn.DataPropertyName = "ContactEmail";
            this.contactEmailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.contactEmailDataGridViewTextBoxColumn.Name = "contactEmailDataGridViewTextBoxColumn";
            // 
            // contactNumberDataGridViewTextBoxColumn
            // 
            this.contactNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.contactNumberDataGridViewTextBoxColumn.DataPropertyName = "ContactNumber";
            this.contactNumberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.contactNumberDataGridViewTextBoxColumn.Name = "contactNumberDataGridViewTextBoxColumn";
            // 
            // customerDataGridViewTextBoxColumn
            // 
            this.customerDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customerDataGridViewTextBoxColumn.DataPropertyName = "Customer";
            this.customerDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customerDataGridViewTextBoxColumn.Name = "customerDataGridViewTextBoxColumn";
            // 
            // contactBindingSource
            // 
            this.contactBindingSource.DataSource = typeof(CustomerContactManager.Contact);
            // 
            // lblContacts
            // 
            this.lblContacts.AutoSize = true;
            this.lblContacts.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblContacts.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContacts.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblContacts.Location = new System.Drawing.Point(0, 0);
            this.lblContacts.Name = "lblContacts";
            this.lblContacts.Size = new System.Drawing.Size(89, 25);
            this.lblContacts.TabIndex = 3;
            this.lblContacts.Text = "Contacts";
            // 
            // pnlContactsMenu
            // 
            this.pnlContactsMenu.Controls.Add(this.btnContactSave);
            this.pnlContactsMenu.Controls.Add(this.btnContactDelete);
            this.pnlContactsMenu.Controls.Add(this.btnContactEdit);
            this.pnlContactsMenu.Controls.Add(this.btnContactAdd);
            this.pnlContactsMenu.Controls.Add(this.btnContactRefresh);
            this.pnlContactsMenu.Controls.Add(this.lblContacts);
            this.pnlContactsMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContactsMenu.Location = new System.Drawing.Point(0, 309);
            this.pnlContactsMenu.Name = "pnlContactsMenu";
            this.pnlContactsMenu.Size = new System.Drawing.Size(974, 50);
            this.pnlContactsMenu.TabIndex = 3;
            // 
            // btnContactSave
            // 
            this.btnContactSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContactSave.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnContactSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnContactSave.Location = new System.Drawing.Point(300, 25);
            this.btnContactSave.Name = "btnContactSave";
            this.btnContactSave.Size = new System.Drawing.Size(75, 25);
            this.btnContactSave.TabIndex = 11;
            this.btnContactSave.Text = "Save";
            this.btnContactSave.UseVisualStyleBackColor = false;
            // 
            // btnContactDelete
            // 
            this.btnContactDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContactDelete.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnContactDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnContactDelete.Location = new System.Drawing.Point(225, 25);
            this.btnContactDelete.Name = "btnContactDelete";
            this.btnContactDelete.Size = new System.Drawing.Size(75, 25);
            this.btnContactDelete.TabIndex = 10;
            this.btnContactDelete.Text = "Delete";
            this.btnContactDelete.UseVisualStyleBackColor = false;
            // 
            // btnContactEdit
            // 
            this.btnContactEdit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContactEdit.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnContactEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactEdit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnContactEdit.Location = new System.Drawing.Point(150, 25);
            this.btnContactEdit.Name = "btnContactEdit";
            this.btnContactEdit.Size = new System.Drawing.Size(75, 25);
            this.btnContactEdit.TabIndex = 9;
            this.btnContactEdit.Text = "Edit";
            this.btnContactEdit.UseVisualStyleBackColor = false;
            // 
            // btnContactAdd
            // 
            this.btnContactAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContactAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnContactAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnContactAdd.Location = new System.Drawing.Point(75, 25);
            this.btnContactAdd.Name = "btnContactAdd";
            this.btnContactAdd.Size = new System.Drawing.Size(75, 25);
            this.btnContactAdd.TabIndex = 8;
            this.btnContactAdd.Text = "Add";
            this.btnContactAdd.UseVisualStyleBackColor = false;
            this.btnContactAdd.Click += new System.EventHandler(this.btnContactAdd_Click);
            // 
            // btnContactRefresh
            // 
            this.btnContactRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContactRefresh.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnContactRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactRefresh.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnContactRefresh.Location = new System.Drawing.Point(0, 25);
            this.btnContactRefresh.Name = "btnContactRefresh";
            this.btnContactRefresh.Size = new System.Drawing.Size(75, 25);
            this.btnContactRefresh.TabIndex = 7;
            this.btnContactRefresh.Text = "Refresh";
            this.btnContactRefresh.UseVisualStyleBackColor = false;
            // 
            // frmCCM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(61)))), ((int)(((byte)(75)))));
            this.ClientSize = new System.Drawing.Size(974, 606);
            this.Controls.Add(this.pnlContactsMenu);
            this.Controls.Add(this.dgvContactTBL);
            this.Controls.Add(this.dgvCustomerTBL);
            this.Controls.Add(this.pnlTopMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCCM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Contact Manager";
            this.Load += new System.EventHandler(this.frmCCM_Load);
            this.pnlTopMenu.ResumeLayout(false);
            this.pnlTopMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerTBL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContactTBL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactBindingSource)).EndInit();
            this.pnlContactsMenu.ResumeLayout(false);
            this.pnlContactsMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopMenu;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnCloseApp;
        private System.Windows.Forms.Label lblAppHeading;
        private System.Windows.Forms.DataGridView dgvCustomerTBL;
        private System.Windows.Forms.DataGridView dgvContactTBL;
        private System.Windows.Forms.Label lblContacts;
        private System.Windows.Forms.Panel pnlContactsMenu;
        private System.Windows.Forms.Button btnContactSave;
        private System.Windows.Forms.Button btnContactDelete;
        private System.Windows.Forms.Button btnContactEdit;
        private System.Windows.Forms.Button btnContactAdd;
        private System.Windows.Forms.Button btnContactRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customer1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn latitudeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn longitudeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactsDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contact1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource contactBindingSource;
    }
}

